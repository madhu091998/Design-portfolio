#!/bin/bash
# Double-click this to start the relay. Leave the window open while you work.
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Node.js isn't installed on this Mac."
  echo ""
  echo "  1. Go to  https://nodejs.org"
  echo "  2. Click the big green LTS button and install it"
  echo "  3. Double-click this file again"
  echo ""
  read -r -p "  Press Return to close this window. "
  exit 1
fi

clear
node server.js
echo ""
read -r -p "  Relay stopped. Press Return to close this window. "
