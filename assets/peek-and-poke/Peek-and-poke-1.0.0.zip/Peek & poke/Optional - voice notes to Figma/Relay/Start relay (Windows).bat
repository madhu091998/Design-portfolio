@echo off
REM Double-click this to start the relay. Leave the window open while you work.
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js isn't installed on this PC.
  echo.
  echo   1. Go to  https://nodejs.org
  echo   2. Click the big green LTS button and install it
  echo   3. Double-click this file again
  echo.
  pause
  exit /b 1
)

cls
node server.js
echo.
echo   Relay stopped.
pause
