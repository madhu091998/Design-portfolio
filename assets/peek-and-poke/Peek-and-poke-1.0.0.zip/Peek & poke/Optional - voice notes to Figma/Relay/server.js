/**
 * Voice Annotator — local relay server.
 *
 * A dependency-free HTTP server that brokers screenshots + per-element voice
 * annotations between the Chrome extension (producer) and the Figma plugin
 * (consumer). Structurally the same shape as the chrome-to-figma relay in this
 * repo, but this is a separate, independent server on its own port — nothing
 * is shared between the two beyond the pattern.
 *
 * Everything lives in a bounded in-memory queue. Nothing is ever written to
 * disk, and a capture is dropped from the queue the moment it is handed to
 * the Figma plugin. Restarting the process discards every pending capture.
 *
 * Endpoints
 *   GET    /health   → { ok, pending, stats }        liveness + queue depth
 *   POST   /capture  → { ok, id, pending }           enqueue a capture (extension)
 *   GET    /next     → 200 capture | 204 empty       dequeue oldest (Figma plugin)
 *   DELETE /queue    → { ok, cleared }               drop everything pending
 */
import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
/**
 * Loopback only. The relay must never be reachable from another machine.
 *
 * Clients address the relay as "localhost" (Figma's networkAccess validator
 * rejects raw IP literals like 127.0.0.1 — it wants a domain-shaped hostname),
 * so both loopback families need a listener: "localhost" can resolve to
 * either 127.0.0.1 or ::1 depending on the machine's DNS/hosts configuration.
 */
const LOOPBACK_HOSTS = ['127.0.0.1', '::1'];
/** A different port from the chrome-to-figma relay (3847) so both can run at once. */
const PORT = Number(process.env.PORT ?? 3849);
/** Hard ceiling on a single request body (~64 MB) — a 6K retina PNG is ~15 MB. */
const MAX_BODY_BYTES = 64 * 1024 * 1024;
/** Most captures the queue will hold. Oldest are evicted first. */
const MAX_QUEUE_LENGTH = 20;
/** Captures nobody collected within this window are discarded. */
const CAPTURE_TTL_MS = 5 * 60 * 1000;
/** Most annotations accepted in a single capture — a sanity ceiling, not a real limit. */
const MAX_ANNOTATIONS = 200;
/** Longest a single spoken/typed annotation's text is allowed to be. */
const MAX_ANNOTATION_TEXT_LENGTH = 4000;
const queue = [];
const stats = {
    received: 0,
    delivered: 0,
    /** Evicted by the queue cap or the TTL, i.e. never reached Figma. */
    dropped: 0,
};
/** Remove captures older than the TTL. Called on every request. */
function pruneExpired() {
    const cutoff = Date.now() - CAPTURE_TTL_MS;
    for (let i = queue.length - 1; i >= 0; i -= 1) {
        if (Date.parse(queue[i].receivedAt) < cutoff) {
            queue.splice(i, 1);
            stats.dropped += 1;
            log('expired a capture that was never collected');
        }
    }
}
// ---------------------------------------------------------------------------
// CORS — local callers only
// ---------------------------------------------------------------------------
/**
 * Origins permitted to talk to the relay.
 *
 * The Figma plugin iframe is sandboxed and sends `Origin: null`, so a null
 * origin has to be accepted for the plugin to work at all. That is tolerable
 * only because the server is bound to loopback interfaces and holds nothing
 * but transient screenshots and notes you produced yourself.
 */
const ALLOWED_ORIGIN_PATTERNS = [
    /^chrome-extension:\/\/[a-p]{32}$/, // the Chrome extension service worker
    /^https:\/\/(www\.)?figma\.com$/, // Figma in the browser
    /^https?:\/\/localhost(:\d+)?$/,
    /^https?:\/\/127\.0\.0\.1(:\d+)?$/,
];
function isAllowedOrigin(origin) {
    // No Origin header at all (curl, same-origin) — allow; we are loopback-bound.
    if (origin === undefined)
        return true;
    // Figma's plugin iframe and the Figma desktop app both send a null origin.
    if (origin === 'null')
        return true;
    return ALLOWED_ORIGIN_PATTERNS.some((pattern) => pattern.test(origin));
}
function applyCorsHeaders(req, res) {
    const origin = req.headers.origin;
    res.setHeader('Access-Control-Allow-Origin', origin ?? 'null');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Max-Age', '600');
    res.setHeader('Vary', 'Origin');
}
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function log(message) {
    const stamp = new Date().toISOString().slice(11, 19);
    console.log(`[${stamp}] ${message}`);
}
function sendJson(res, status, body) {
    const payload = JSON.stringify(body);
    res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(payload),
        'Cache-Control': 'no-store',
    });
    res.end(payload);
}
function sendError(res, status, message) {
    sendJson(res, status, { ok: false, error: message });
}
/** An error carrying the HTTP status the caller should receive. */
class HttpError extends Error {
    status;
    constructor(status, message) {
        super(message);
        this.status = status;
    }
}
/** Read the whole request body, refusing anything over MAX_BODY_BYTES. */
function readBody(req) {
    const tooLarge = new HttpError(413, `Request body exceeds the ${Math.round(MAX_BODY_BYTES / (1024 * 1024))} MB limit`);
    // Reject before reading a single byte when the client declares the size.
    const declared = Number(req.headers['content-length']);
    if (Number.isFinite(declared) && declared > MAX_BODY_BYTES) {
        return Promise.reject(tooLarge);
    }
    return new Promise((resolve, reject) => {
        const chunks = [];
        let size = 0;
        req.on('data', (chunk) => {
            size += chunk.length;
            if (size > MAX_BODY_BYTES) {
                // Backstop for chunked uploads with no content-length. Stop buffering,
                // but let the response flush before the socket goes away.
                chunks.length = 0;
                req.pause();
                reject(tooLarge);
                return;
            }
            chunks.push(chunk);
        });
        req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        req.on('error', reject);
    });
}
function formatBytes(bytes) {
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
/** Strip a `data:image/png;base64,` prefix if the caller left one on. */
function stripDataUrlPrefix(value) {
    const comma = value.indexOf(',');
    return value.startsWith('data:') && comma !== -1 ? value.slice(comma + 1) : value;
}
const PNG_MAGIC = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
/**
 * Validate and normalize the `annotations` array on an incoming capture.
 * Throws HttpError(400, ...) on the first structurally invalid entry rather
 * than silently dropping it — a malformed annotation almost always means a
 * bug in the extension, not something to quietly paper over.
 */
function parseAnnotations(raw) {
    if (raw === undefined)
        return [];
    if (!Array.isArray(raw))
        throw new HttpError(400, '"annotations" must be an array');
    if (raw.length > MAX_ANNOTATIONS) {
        throw new HttpError(400, `"annotations" exceeds the ${MAX_ANNOTATIONS}-item limit`);
    }
    return raw.map((entry, index) => {
        if (typeof entry !== 'object' || entry === null) {
            throw new HttpError(400, `annotations[${index}] must be an object`);
        }
        const a = entry;
        for (const key of ['x', 'y', 'width', 'height']) {
            if (typeof a[key] !== 'number' || !Number.isFinite(a[key])) {
                throw new HttpError(400, `annotations[${index}].${key} must be a finite number`);
            }
        }
        if (a.width <= 0 || a.height <= 0) {
            throw new HttpError(400, `annotations[${index}] must have positive width and height`);
        }
        if (typeof a.text !== 'string' || a.text.trim().length === 0) {
            throw new HttpError(400, `annotations[${index}].text must be a non-empty string`);
        }
        if (a.text.length > MAX_ANNOTATION_TEXT_LENGTH) {
            throw new HttpError(400, `annotations[${index}].text exceeds ${MAX_ANNOTATION_TEXT_LENGTH} characters`);
        }
        return {
            x: a.x,
            y: a.y,
            width: a.width,
            height: a.height,
            text: a.text.trim(),
            label: typeof a.label === 'string' && a.label.trim() ? a.label.trim() : 'element',
        };
    });
}
// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------
function handleHealth(res) {
    sendJson(res, 200, {
        ok: true,
        service: 'voice-annotator-relay',
        pending: queue.length,
        stats: { ...stats },
    });
}
async function handleCapture(req, res) {
    let parsed;
    try {
        parsed = JSON.parse(await readBody(req));
    }
    catch (error) {
        const status = error instanceof HttpError ? error.status : 400;
        const message = error instanceof Error ? error.message : 'Invalid JSON body';
        log(`rejected capture (${status}): ${message}`);
        if (status === 413) {
            // The client may still be uploading; close rather than wait it out.
            res.setHeader('Connection', 'close');
            res.on('finish', () => req.socket.destroy());
        }
        sendError(res, status, message);
        return;
    }
    if (typeof parsed !== 'object' || parsed === null) {
        sendError(res, 400, 'Body must be a JSON object');
        return;
    }
    const body = parsed;
    const rawPng = body.pngBase64;
    if (typeof rawPng !== 'string' || rawPng.length === 0) {
        sendError(res, 400, 'Missing "pngBase64"');
        return;
    }
    const pngBase64 = stripDataUrlPrefix(rawPng);
    const decoded = Buffer.from(pngBase64, 'base64');
    if (decoded.length === 0) {
        sendError(res, 400, '"pngBase64" did not decode to any bytes');
        return;
    }
    if (!decoded.subarray(0, 8).equals(PNG_MAGIC)) {
        sendError(res, 400, 'Payload is not a PNG (bad magic bytes)');
        return;
    }
    let annotations;
    try {
        annotations = parseAnnotations(body.annotations);
    }
    catch (error) {
        const status = error instanceof HttpError ? error.status : 400;
        const message = error instanceof Error ? error.message : 'Invalid annotations';
        log(`rejected capture (${status}): ${message}`);
        sendError(res, status, message);
        return;
    }
    const capture = {
        id: randomUUID(),
        title: typeof body.title === 'string' && body.title.trim() ? body.title.trim() : 'Untitled page',
        url: typeof body.url === 'string' ? body.url : '',
        capturedAt: typeof body.capturedAt === 'string' ? body.capturedAt : new Date().toISOString(),
        receivedAt: new Date().toISOString(),
        pngBase64,
        byteLength: decoded.length,
        annotations,
    };
    queue.push(capture);
    stats.received += 1;
    // Bound memory: evict oldest first if the plugin isn't keeping up.
    while (queue.length > MAX_QUEUE_LENGTH) {
        queue.shift();
        stats.dropped += 1;
        log(`queue full (${MAX_QUEUE_LENGTH}) — dropped the oldest pending capture`);
    }
    log(`+ queued "${capture.title}" (${formatBytes(capture.byteLength)}, ` +
        `${annotations.length} annotation${annotations.length === 1 ? '' : 's'}) — ${queue.length} pending`);
    sendJson(res, 200, { ok: true, id: capture.id, pending: queue.length });
}
function handleNext(res) {
    const capture = queue.shift();
    if (!capture) {
        // 204 keeps the poll loop cheap: no body, nothing to parse.
        res.writeHead(204, { 'Cache-Control': 'no-store' });
        res.end();
        return;
    }
    stats.delivered += 1;
    log(`→ delivered "${capture.title}" to Figma — ${queue.length} pending`);
    // The capture is already out of the queue; this response is the only copy.
    sendJson(res, 200, { ok: true, capture, pending: queue.length });
}
function handleClearQueue(res) {
    const cleared = queue.length;
    queue.length = 0;
    stats.dropped += cleared;
    if (cleared > 0)
        log(`cleared ${cleared} pending capture(s)`);
    sendJson(res, 200, { ok: true, cleared });
}
// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------
const requestListener = (req, res) => {
    const method = req.method ?? 'GET';
    const path = new URL(req.url ?? '/', `http://localhost:${PORT}`).pathname;
    if (!isAllowedOrigin(req.headers.origin)) {
        log(`blocked request from disallowed origin: ${req.headers.origin}`);
        sendError(res, 403, 'Origin not allowed');
        return;
    }
    applyCorsHeaders(req, res);
    if (method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }
    pruneExpired();
    void (async () => {
        try {
            if (method === 'GET' && path === '/health')
                return handleHealth(res);
            if (method === 'POST' && path === '/capture')
                return await handleCapture(req, res);
            if (method === 'GET' && path === '/next')
                return handleNext(res);
            if (method === 'DELETE' && path === '/queue')
                return handleClearQueue(res);
            sendError(res, 404, `No route for ${method} ${path}`);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            log(`unhandled error on ${method} ${path}: ${message}`);
            if (!res.headersSent)
                sendError(res, 500, message);
            else
                res.end();
        }
    })();
};
/**
 * One HTTP server per loopback family, all sharing `requestListener` (and thus
 * the same in-memory queue). A machine with IPv6 disabled will simply fail to
 * bind ::1 — that's fine as long as 127.0.0.1 comes up.
 */
const servers = LOOPBACK_HOSTS.map(() => createServer(requestListener));
let boundCount = 0;
servers.forEach((server, index) => {
    const host = LOOPBACK_HOSTS[index];
    server.on('error', (error) => {
        if (error.code === 'EADDRINUSE') {
            console.error(`\n  Port ${PORT} is already in use on ${host}.\n` +
                `  Another copy of the relay is probably running — stop it, or run with PORT=... set.\n`);
            process.exit(1);
        }
        if (error.code === 'EAFNOSUPPORT' || error.code === 'EADDRNOTAVAIL') {
            // No IPv6 stack (or it's disabled) — the other loopback family covers us.
            log(`skipping ${host} (${error.code}) — not available on this machine`);
            return;
        }
        console.error(`Relay server error on ${host}:`, error);
        process.exit(1);
    });
    server.listen(PORT, host, () => {
        boundCount += 1;
        if (boundCount === 1) {
            console.log(`
  Peek & poke relay
  -----------------
  Listening on   http://localhost:${PORT}  (${LOOPBACK_HOSTS.join(' + ')})
  Storage        in-memory only, cleared on delivery
  Queue limit    ${MAX_QUEUE_LENGTH} captures / ${CAPTURE_TTL_MS / 1000}s TTL

  Waiting for captures. Press Ctrl+C to stop.
`);
        }
    });
});
for (const signal of ['SIGINT', 'SIGTERM']) {
    process.on(signal, () => {
        const lost = queue.length;
        queue.length = 0;
        console.log(`\nShutting down${lost > 0 ? ` — discarded ${lost} pending capture(s)` : ''}.`);
        for (const server of servers)
            server.close();
        // Don't wait on lingering keep-alive poll connections.
        setTimeout(() => process.exit(0), 500).unref();
    });
}
